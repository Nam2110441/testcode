import sqlite3

def query_database(question):
    conn = sqlite3.connect("chatbot_data.db")
    cursor = conn.cursor()
    cursor.execute("SELECT answer FROM medical_data WHERE question = ?", (question,))
    result = cursor.fetchone()
    conn.close()
    return result[0] if result else "Xin lỗi, tôi không biết câu trả lời."

def main():
    print("Gõ 'exit' để thoát.")
    while True:
        question = input("Bạn: ").strip()
        if question.lower() == "exit":
            break
        answer = query_database(question)
        print(f"Bot: {answer}")

if __name__ == "__main__":
    main()
