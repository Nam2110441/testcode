import sqlite3

sample_data = [
    ("Cảm cúm là gì?", "Cảm cúm là bệnh nhiễm virus gây ra bởi virus influenza."),
    ("Làm sao để phòng tránh sốt xuất huyết?", "Bạn nên diệt muỗi, dọn dẹp nơi trú ẩn của muỗi và ngủ màn."),
    ("Ăn gì để tăng sức đề kháng?", "Bạn nên ăn nhiều trái cây, rau xanh, và thực phẩm giàu vitamin C, D."),
    ("Làm sao để giảm cân hiệu quả?", "Hãy ăn uống lành mạnh, giảm tinh bột, tập thể dục đều đặn.")
]

def create_database():
    conn = sqlite3.connect("chatbot_data.db")
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS medical_data (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            question TEXT UNIQUE,
            answer TEXT
        )
    """)
    cursor.executemany("INSERT OR IGNORE INTO medical_data (question, answer) VALUES (?, ?)", sample_data)
    conn.commit()
    conn.close()

if __name__ == "__main__":
    create_database()
    print("Database initialized successfully!")
